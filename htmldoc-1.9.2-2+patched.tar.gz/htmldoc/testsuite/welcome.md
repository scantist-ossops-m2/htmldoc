# "Welcome" in Many Languages

Welcome
Welkom
ḫaṣānu
Mayad-ayad nga pad-abot
Mir se vjên
Mirë se vjen
Wellkumma
Bienveniu
Ghini vinit!
Bienveníu
Miro peicak
Xoş gəlmişsiniz!
Salamat datang
Сәләм бирем!
Menjuah-juah!
Še das d' kemma bisd
Mwaiseni
Maogmáng Pag-abót
Welkam
Dobrodošli
Degemer mat
Benvingut
Maayong pag-abot
Kopisanangan do kinorikatan
Bienvenida
Bien binidu
Bienbenidu
Hóʔą
Boolkhent!
Kopivosian do kinoikatan
Malipayeng Pag-abot!
Vítej
Velkommen
Salâm
Welkom
Emedi
Welkumin
Tere tulemast
Woé zɔ
Bienveníu
Vælkomin
Bula
Tervetuloa
Bienvenue
Wäljkiimen
Wäilkuumen
Wäilkuumen
Wolkom
Benvignût
Benvido
Willkommen
Ἀσπάζομαι!
Καλώς Ήρθες
Tikilluarit
Byen venu
Sannu da zuwa
Aloha
Wayakurua
Dayón
Zoo siab txais tos!
Üdvözlet
Selamat datai
Velkomin
Nnọọ
Selamat datang
Qaimarutin
Fáilte
Benvenuto
Voschata
Murakaza neza
Mauri
Tu be xér hatî ye!
Taŋyáŋ yahí
Salve
Laipni lūdzam
Wilkóm
Sveiki atvykę
Willkamen
Mu amuhezwi
Tukusanyukidde
Wëllkomm
Swagatam
Tonga soa
Selamat datang
Merħba
B’a’ntulena
Failt ort
Haere mai
mai
Pjila’si
Benvegnüu
Ne y kena
Ximopanōltih
Yá'át'ééh
Siyalemukela
Siyalemukela
Bures boahtin
Re a go amogela
Velkommen
Benvengut!
Bon bini
Witam Cię
Bem-vindo
Haykuykuy!
T'aves baxtalo
Bainvegni
Afio mai
Ennidos
Walcome
Fàilte
Mauya
Bon vinutu
Vitaj
Dobrodošli
Soo dhowow
Witaj
Bienvenido
Wilujeng sumping
Karibu
Wamukelekile
Välkommen
Wilkomme
Maligayang pagdating
Maeva
Räxim itegez
Ksolok Bodik Mai
Ulu tons mai
Welkam
Talitali fiefia
Lek oy li la tale
amogetswe
Tempokani
Hoş geldin
Koş geldiniz
Ulufale mai!
Xush kelibsiz
Benvignùo
Tervhen tuldes
Hoan nghênh
Tere tulõmast
Benvnuwe
Croeso
Merhbe
Wamkelekile
Märr-ŋamathirri
Ẹ ku abọ
Kíimak 'oolal
Ngiyakwemukela
